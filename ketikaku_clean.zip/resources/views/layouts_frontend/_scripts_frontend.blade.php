<script src="{{ asset('assets/js/jquery.js') }}"></script>
<script src="{{ asset('assets/js/jquery.migrate.js') }}"></script>
<script src="{{ asset('assets/scripts/bootstrap/bootstrap.min.js') }}"></script>
{{-- <script>var $target_end=$(".best-of-the-week");</script> --}}
<script src="{{ asset('assets/scripts/jquery-number/jquery.number.min.js') }}"></script>
<script src="{{ asset('assets/scripts/owlcarousel/dist/owl.carousel.min.js') }}"></script>
<script src="{{ asset('assets/scripts/magnific-popup/dist/jquery.magnific-popup.min.js') }}"></script>
<script src="{{ asset('assets/scripts/easescroll/jquery.easeScroll.js') }}"></script>
<script src="{{ asset('assets/scripts/sweetalert/dist/sweetalert.min.js') }}"></script>
<script src="{{ asset('assets/scripts/toast/jquery.toast.min.js') }}"></script>
{{-- <script src="{{ asset('assets/js/demo.js') }}"></script> --}}
<script src="{{ asset('assets/js/e-magz.js') }}"></script>
<script src="{{ asset('assets_backend/extra-libs/DataTables/datatables.min.js') }}"></script>

<script src="{{ asset('assets_backend/libs/iziToast-master/dist/js/iziToast.min.js') }}"></script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" integrity="sha384-gfdkjb5BdAXd+lj+gudLWI+BXq4IuLW5IT+brZEZsLFm++aCMlF1V92rMkPaX4PP" crossorigin="anonymous">
<script src="{{ asset('assets_backend/libs/tinymce/tinymce.min.js') }}"></script>


<script type="text/javascript">
	
	var baseUrl = ('{{ url('/') }}');

</script>