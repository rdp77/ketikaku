<?php

namespace App\Http\Controllers\backend\mail;

use App\Http\Controllers\Controller;
use Auth;
use Illuminate\Http\Request;
use Validator;
use DB; 
use Storage;
use App\d_mem;

class verifyController extends Controller
{
    
}
