    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <meta name="description" content="ESENSI CREATIVE.">
        <meta name="author" content="ESENSI">
        <meta name="keyword" content="ketikau, novel, chapter, magazine">
        <!-- Shareable -->
        <meta property="og:title" content="KETIKAKU : CERITA PADA DUNIA " />
        <meta property="og:type" content="article" />
        <meta property="og:url" content="http://ketikaku.com/" />
        <meta property="og:description" content="Ketikaku adalah online sharing platform karya Aksara Satmika, sebagai wadah bagi pembaca dan penulis bercerita pada dunia." />
        <meta property="og:image" content="<?php echo e(asset('assets_backend/images/favicon.png')); ?>" />
        <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('assets_backend/images/favicon.png')); ?>">
        <title>KETIKAKU</title>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    </head>