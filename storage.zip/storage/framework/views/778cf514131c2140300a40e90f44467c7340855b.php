<!DOCTYPE html>
<html>
    <?php echo $__env->make('layouts_frontend._head_frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('layouts_frontend._css_frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('extra_style'); ?>
    <body class="skin-orange">
        <?php echo $__env->make('layouts_frontend._nav_frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    </body>
    <?php echo $__env->make('layouts_frontend._footer_frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('layouts_frontend._scripts_frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('extra_scripts'); ?>
</html>