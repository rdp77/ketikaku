<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<!-- Tell the browser to be responsive to screen width -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="APASIHH">
<meta name="author" content="DENYPRASS">
<meta name="keywords" content="WordPress, Blogger, Blogspot, Drupal">
<!-- Favicon icon -->
<link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('assets_backend/images/favicon.png')); ?>">
<title>KETIKAKU</title>
