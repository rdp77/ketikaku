

<?php $__env->startSection('extra_style'); ?>
<style type="text/css">
    .kuning{
      color: #ffd119;
      font-size: 14px;
    }
    .article .padding{
        padding: 10px 10px 50px !important;
    }
    .love i:before{
        font-size: 20px !important;
    }
    .love div{
        margin-top: 1px !important;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="home">
            <div class="container">
                <div class="row">
                    <div class="col-md-9 col-sm-12 col-xs-12">
                        <div class="headline">
                           
                        </div>
                        <div class="owl-carousel owl-theme slide" id="featured">
                            <div class="item">
                                <article class="featured">
                                    <div class="overlay"></div>
                                    <figure>
                                        <img src="<?php echo e(asset('assets/images/banner/1.jpg')); ?>" alt="Sample Article">
                                    </figure>
                                   
                                </article>
                            </div>
                            <div class="item">
                                <article class="featured">
                                    <div class="overlay"></div>
                                    <figure>
                                        <img src="<?php echo e(asset('assets/images/banner/2.jpg')); ?>" alt="Sample Article">
                                    </figure>
                                    
                                </article>
                            </div>
                            <div class="item">
                                <article class="featured">
                                    <div class="overlay"></div>
                                    <figure>
                                        <img src="<?php echo e(asset('assets/images/banner/3.jpg')); ?>" alt="Sample Article">
                                    </figure>
                                    
                                </article>
                            </div>
                           
                        </div>
                        <div class="line">
                            <div>OFFICIAL</div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="row">
                                    <?php $__currentLoopData = $data_official; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <article class="article col-md-3 col-xs-6">
                                        <div class="inner">
                                            <figure>
                                                <a href="<?php echo e(asset('/book/'.$element->dn_id.'/'.str_replace(" ","-",$element->dn_title))); ?>">
                                                    <?php if($element->dn_cover == null): ?>
                                                        <img src="<?php echo e(asset('assets/images/noimage.jpg' )); ?>" height="300px" alt="<?php echo e($element->dn_title); ?>">
                                                    <?php else: ?>
                                                        <img src="<?php echo e(asset('storage/app/'.$element->dn_cover )); ?>" height="300px" alt="<?php echo e($element->dn_title); ?>">
                                                    <?php endif; ?>
                                                </a>
                                            </figure>
                                            <div class="padding">
                                                <h6 style="font-size: 12px"><a href="<?php echo e(asset('/book/'.$element->dn_id.'/'.str_replace(" ","-",$element->dn_title))); ?>"><input type="text" readonly="" style="width: 100%;border: none;cursor: pointer;" value="<?php echo e($element->dn_title); ?>" name=""></a></h6>
                                                <footer>
                                                    <span class="love active"><i class="ion-android-favorite"></i> <div class="liked"><?php if($element->liked == null): ?> 0 <?php else: ?> <?php echo e($element->liked); ?> <?php endif; ?></div></span>
                                                    <span class="love active"><i class="fas fa-users"></i> <div class="subscribed"><?php if($element->subscribed == null): ?> 0 <?php else: ?> <?php echo e($element->subscribed); ?> <?php endif; ?></div></span>
                                                    <span class="love active"><i class="fas fa-eye"></i> <div class="viewer"><?php if($element->viewer == null): ?> 0 <?php else: ?> 
                                                        <?php
                                                        $n = $element->viewer;
                                                        $precision = 1; 
                                                        if ($n < 900) {
                                                            // 0 - 900
                                                            $n_format = number_format($n, $precision);
                                                            $suffix = '';
                                                        } else if ($n < 900000) {
                                                            // 0.9k-850k
                                                            $n_format = number_format($n / 1000, $precision);
                                                            $suffix = 'K';
                                                        } else if ($n < 900000000) {
                                                            // 0.9m-850m
                                                            $n_format = number_format($n / 1000000, $precision);
                                                            $suffix = 'M';
                                                        } else if ($n < 900000000000) {
                                                            // 0.9b-850b
                                                            $n_format = number_format($n / 1000000000, $precision);
                                                            $suffix = 'B';
                                                        } else {
                                                            // 0.9t+
                                                            $n_format = number_format($n / 1000000000000, $precision);
                                                            $suffix = 'T';
                                                        }

                                                        if ( $precision > 0 ) {
                                                            $dotzero = '.' . str_repeat( '0', $precision );
                                                            $n_format = str_replace( $dotzero, '', $n_format );
                                                        }
                                                        echo($n_format.$suffix);
                                                        ?>
                                                        <?php endif; ?></div></span>
                                                </footer>
                                            </div>
                                        </div>
                                    </article>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </div>
                                <?php if(count($data_official) >= 8): ?>
                                <div>
                                   <button class="btn btn-primary load_more_official"><i class="fas fa-arrow-right"></i>Load More</button>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="line">
                            <div>POPULAR</div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="row">
                                    <?php $__currentLoopData = $data_popular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <article class="article col-md-3 col-xs-6">
                                        <div class="inner">
                                            <figure>
                                                <a href="<?php echo e(asset('/book/'.$element->dn_id.'/'.str_replace(" ","-",$element->dn_title))); ?>">
                                                    <?php if($element->dn_cover == null): ?>
                                                        <img src="<?php echo e(asset('assets/images/noimage.jpg' )); ?>" height="300px" alt="<?php echo e($element->dn_title); ?>">
                                                    <?php else: ?>
                                                        <img src="<?php echo e(asset('storage/app/'.$element->dn_cover )); ?>" height="300px" alt="<?php echo e($element->dn_title); ?>">
                                                    <?php endif; ?>
                                                </a>
                                            </figure>
                                            <div class="padding">
                                                <h6 style="font-size: 12px"><a href="<?php echo e(asset('/book/'.$element->dn_id.'/'.str_replace(" ","-",$element->dn_title))); ?>"><input type="text" readonly="" style="width: 100%;border: none;cursor: pointer;" value="<?php echo e($element->dn_title); ?>" name=""></a></h6>
                                                <footer>
                                                    <span class="love active"><i class="ion-android-favorite"></i> <div><?php if($element->liked == null): ?> 0 <?php else: ?> <?php echo e($element->liked); ?> <?php endif; ?></div></span>
                                                    <span class="love active"><i class="fas fa-users"></i> <div><?php if($element->liked == null): ?> 0 <?php else: ?> <?php echo e($element->subscribed); ?> <?php endif; ?></div></span>
                                                    <span class="love active"><i class="fas fa-eye"></i> <div><?php if($element->liked == null): ?> 0 <?php else: ?> <?php echo e($element->viewer); ?> <?php endif; ?></div></span>
                                                </footer>
                                            </div>
                                        </div>
                                    </article>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <?php if(count($data_popular) >= 8): ?>
                                <div>
                                   <button class="btn btn-primary load_more_popular"><i class="fas fa-arrow-right"></i>Load More</button>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="line">
                            <div>LIKE</div>
                        </div>
                          <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="row">
                                    <?php $__currentLoopData = $data_like; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <article class="article col-md-3 col-xs-6">
                                        <div class="inner">
                                            <figure>
                                                <a href="<?php echo e(asset('/book/'.$element->dn_id.'/'.str_replace(" ","-",$element->dn_title))); ?>">
                                                    <?php if($element->dn_cover == null): ?>
                                                        <img src="<?php echo e(asset('assets/images/noimage.jpg' )); ?>" height="300px" alt="<?php echo e($element->dn_title); ?>">
                                                    <?php else: ?>
                                                        <img src="<?php echo e(asset('storage/app/'.$element->dn_cover )); ?>" height="300px" alt="<?php echo e($element->dn_title); ?>">
                                                    <?php endif; ?>
                                                </a>
                                            </figure>
                                            <div class="padding">
                                                <h6 style="font-size: 12px"><a href="<?php echo e(asset('/book/'.$element->dn_id.'/'.str_replace(" ","-",$element->dn_title))); ?>"><input type="text" style="width: 100%;border: none;cursor: pointer;" value="<?php echo e($element->dn_title); ?>" name=""></a></h6>
                                                <footer>
                                                    <span class="love active"><i class="ion-android-favorite"></i> <div class="liked"><?php if($element->liked == null): ?> 0 <?php else: ?> <?php echo e($element->liked); ?> <?php endif; ?></div></span>
                                                    <span class="love active"><i class="fas fa-users"></i> <div class="subscribed"><?php if($element->subscribed == null): ?> 0 <?php else: ?> <?php echo e($element->subscribed); ?> <?php endif; ?></div></span>
                                                    <span class="love active"><i class="fas fa-eye"></i> <div class="viewer"><?php if($element->viewer == null): ?> 0 <?php else: ?> <?php echo e($element->viewer); ?> <?php endif; ?></div></span>
                                                </footer>
                                            </div>
                                        </div>
                                    </article>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <?php if(count($data_like) >= 8): ?>
                                <div>
                                   <button class="btn btn-primary load_more_like"><i class="fas fa-arrow-right"></i>Load More</button>
                                </div>
                                <?php endif; ?>
                            </div>
                        <div class="line">
                            <div>LATEST</div>
                        </div>
                          <div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="row">
                                    <?php $__currentLoopData = $data_latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <article class="article col-md-3 col-xs-6">
                                        <div class="inner">
                                            <figure>
                                                <a href="<?php echo e(asset('/book/'.$element->dn_id.'/'.str_replace(" ","-",$element->dn_title))); ?>">
                                                    <?php if($element->dn_cover == null): ?>
                                                        <img src="<?php echo e(asset('assets/images/noimage.jpg' )); ?>" height="300px" alt="<?php echo e($element->dn_title); ?>">
                                                    <?php else: ?>
                                                        <img src="<?php echo e(asset('storage/app/'.$element->dn_cover )); ?>" height="300px" alt="<?php echo e($element->dn_title); ?>">
                                                    <?php endif; ?>
                                                </a>
                                            </figure>
                                            <div class="padding">
                                                <h6 style="font-size: 12px"><a href="<?php echo e(asset('/book/'.$element->dn_id.'/'.str_replace(" ","-",$element->dn_title))); ?>"><input type="text" style="width: 100%;border: none;cursor: pointer;" value="<?php echo e($element->dn_title); ?>" name=""></a></h6>
                                                <footer>
                                                    <span class="love active"><i class="ion-android-favorite"></i> <div class="liked"><?php if($element->liked == null): ?> 0 <?php else: ?> <?php echo e($element->liked); ?> <?php endif; ?></div></span>
                                                    <span class="love active"><i class="fas fa-users"></i> <div class="subscribed"><?php if($element->subscribed == null): ?> 0 <?php else: ?> <?php echo e($element->subscribed); ?> <?php endif; ?></div></span>
                                                    <span class="love active"><i class="fas fa-eye"></i> <div class="viewer"><?php if($element->viewer == null): ?> 0 <?php else: ?> <?php echo e($element->viewer); ?> <?php endif; ?></div></span>
                                                </footer>
                                            </div>
                                        </div>
                                    </article>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <?php if(count($data_latest) >= 8): ?>
                                <div>
                                   <button class="btn btn-primary load_more_latest"><i class="fas fa-arrow-right"></i>Load More</button>
                                </div>
                                <?php endif; ?>
                            </div>
                    </div>
                </div>
            </div>
            <div class="col-xs-6 col-md-3 sidebar" id="sidebar">
                        <div class="sidebar-title for-tablet">Sidebar</div>
                        
                        <aside>
                            <ul class="nav nav-tabs nav-justified" role="tablist">
                                <li class="active">
                                    <a href="#popular_writter" aria-controls="popular_writter" role="tab" data-toggle="tab">
                                         Popular Writer
                                    </a>
                                </li>
                                
                            </ul>
                            <div class="tab-content">
                                <div class="tab-pane active" id="popular_writter">
                                    <?php $__currentLoopData = $popular_writter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($index == 0): ?>
                                        <article class="article-fw">
                                            <div class="inner">
                                                <figure style="margin-left: 30px" >
                                                    <a href="<?php echo e(route('profile_frontend',['name'=>$popular_writter[0]->m_username])); ?>">
                                                        <?php if($popular_writter[0]->m_image == null): ?>
                                                            <img style=" border-radius: 50%;height: 150px; width: 150px;" src="<?php echo e(asset('assets_backend/images/no_image.png')); ?>?<?php echo e(time()); ?>" />
                                                        <?php else: ?>
                                                            <img style=" border-radius: 50%;height: 150px; width: 150px;" src="<?php echo e(asset('/storage/app/'.$popular_writter[0]->m_image)); ?>?<?php echo e(time()); ?>" />
                                                        <?php endif; ?>
                                                    </a>
                                                </figure>
                                                <div class="details">
                                                    <div class="detail">
                                                        <div class="time">
                                                            <?php if($popular_writter[0]->subscriber == null): ?> 0 Subscriber 
                                                            <?php else: ?> <?php echo e($popular_writter[0]->subscriber); ?> Subscriber <?php endif; ?>
                                                        </div>
                                                        
                                                    </div>
                                                    <h1><a href="<?php echo e(route('profile_frontend',['name'=>$popular_writter[0]->m_username])); ?>"><?php echo e($popular_writter[0]->m_username); ?></a></h1>
                                                    <p>
                                                        <?php echo e($popular_writter[0]->m_desc_short); ?> 
                                                    </p>
                                                </div>
                                            </div>
                                        </article>
                                        <hr>
                                        
                                        <?php else: ?>
                                            <article class="article-mini">
                                                <div class="inner" style="width: 100%">
                                                    <figure >
                                                        <a href="<?php echo e(route('profile_frontend',['name'=>$popular_writter[$index]->m_username])); ?>">
                                                            <?php if($popular_writter[$index]->m_image == null): ?>
                                                                <img style=" border-radius: 50%;height: 50px; width: 50px;" src="<?php echo e(asset('assets_backend/images/no_image.png')); ?>?<?php echo e(time()); ?>" />
                                                            <?php else: ?>
                                                                <img style=" border-radius: 50%;height: 50px; width: 50px;" src="<?php echo e(asset('/storage/app/'.$popular_writter[$index]->m_image)); ?>?<?php echo e(time()); ?>" />
                                                            <?php endif; ?>
                                                        </a>
                                                    </figure>
                                                    <div  style="margin-left: 55px" class="padding">
                                                        <h1 style="margin-top: 2px;"><a href="<?php echo e(route('profile_frontend',['name'=>$popular_writter[$index]->m_username])); ?>"><?php echo e($popular_writter[$index]->m_username); ?></a></h1>
                                                        <div class="detail">
                                                            
                                                        <div class="time">
                                                            <?php if($popular_writter[$index]->subscriber == null): ?> 0 Subscriber 
                                                            <?php else: ?> <?php echo e($popular_writter[$index]->subscriber); ?> Subscriber <?php endif; ?>
                                                        </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </article>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                        </aside>


                        <aside>
                            <ul class="nav nav-tabs nav-justified" role="tablist">
                                <li class="active">
                                    <a href="#review" aria-controls="review" role="tab" data-toggle="tab">
                                        <i class="ion-android-star-outline"></i> Review
                                    </a>
                                </li>
                                <li>
                                    <a href="#comments" aria-controls="comments" role="tab" data-toggle="tab">
                                        <i class="ion-ios-chatboxes-outline"></i> Comments
                                    </a>
                                </li>
                            </ul>
                            <div class="tab-content">
                                <div class="tab-pane active comments" id="review">
                                    <div class="comment-list sm">
                                        <?php $__currentLoopData = $review; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="item">
                                            <div class="user">                                
                                                <figure>
                                                    <?php if($element->m_image != null): ?>
                                                        <img src="<?php echo e(asset('/storage/app/'.$element->m_image)); ?>?<?php echo e(time()); ?>">
                                                    <?php else: ?>
                                                        <img src="<?php echo e(asset('assets_backend/images/no_image.png')); ?>?<?php echo e(time()); ?>" >
                                                    <?php endif; ?>
                                                </figure>
                                                <div class="details">
                                                    <h5 class="name"><?php echo e($element->m_username); ?>

                                                        
                                                    </h5>
                                                    <p>
                                                        <?php if($element->dr_rate == 1): ?>
                                                            <i class="fas fa-star kuning"></i>
                                                            <i class="far fa-star kuning"></i>
                                                            <i class="far fa-star kuning"></i>
                                                            <i class="far fa-star kuning"></i>
                                                            <i class="far fa-star kuning"></i>
                                                        <?php elseif($element->dr_rate == 2): ?>
                                                            <i class="fas fa-star kuning"></i>
                                                            <i class="fas fa-star kuning"></i>
                                                            <i class="far fa-star kuning"></i>
                                                            <i class="far fa-star kuning"></i>
                                                            <i class="far fa-star kuning"></i>
                                                        <?php elseif($element->dr_rate == 3): ?>
                                                            <i class="fas fa-star kuning"></i>
                                                            <i class="fas fa-star kuning"></i>
                                                            <i class="fas fa-star kuning"></i>
                                                            <i class="far fa-star kuning"></i>
                                                            <i class="far fa-star kuning"></i>
                                                        <?php elseif($element->dr_rate == 4): ?>
                                                            <i class="fas fa-star kuning"></i>
                                                            <i class="fas fa-star kuning"></i>
                                                            <i class="fas fa-star kuning"></i>
                                                            <i class="fas fa-star kuning"></i>
                                                            <i class="far fa-star kuning"></i>
                                                        <?php elseif($element->dr_rate == 5): ?>
                                                            <i class="fas fa-star kuning"></i>
                                                            <i class="fas fa-star kuning"></i>
                                                            <i class="fas fa-star kuning"></i>
                                                            <i class="fas fa-star kuning"></i>
                                                            <i class="fas fa-star kuning"></i>
                                                        <?php endif; ?>
                                                    </p>
                                                    <div class="time"><?php echo e(date('d F Y',strtotime($element->dr_created_at))); ?> <small><?php echo e(date('h:i A',strtotime($element->dr_created_at))); ?></small></div>
                                                    <div class="description">
                                                        <?php echo e($element->dr_message); ?>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <div class="tab-pane comments" id="comments">
                                    <div class="comment-list sm">
                                        <div class="item">
                                            <div class="user">                                
                                                <figure>
                                                    <img src="<?php echo e(asset('assets/images/img01.jpg"')); ?> alt="User Picture">
                                                </figure>
                                                <div class="details">
                                                    <h5 class="name">Mark Otto</h5>
                                                    <div class="time">24 Hours</div>
                                                    <div class="description">
                                                        Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </aside>


                        <aside>
                            <div class="aside-body">
                                <form class="newsletter">
                                    <div class="icon">
                                        <i class="ion-ios-email-outline"></i>
                                        <h1>Newsletter</h1>
                                    </div>
                                    <div class="input-group">
                                        <input type="email" class="form-control email" placeholder="Your mail">
                                        <div class="input-group-btn">
                                            <button class="btn btn-primary"><i class="ion-paper-airplane"></i></button>
                                        </div>
                                    </div>
                                    <p>By subscribing you will receive new articles in your email.</p>
                                </form>
                            </div>
                        </aside>
                        
                    </div>
        </div>
    </div>

        </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra_scripts'); ?>


<script type="text/javascript">
    
    function link(response, urlPath) {
        // window.location.assign('www.esensicreative.com');
        // function processAjaxData(response, urlPath){

     // document.getElementById("content").innerHTML = response.html;
     // document.title = response.pageTitle;

 // }
    }
    // $(function(){
    //   $(window).scroll(function(){
    //     var aTop = 1;
    //     if($(this).scrollTop()>=aTop){
    //     window.history.pushState({"html":'gege',"pageTitle":'title'},"", 'gggg');
    //     }else{
    //     window.history.pushState({"html":'gege',"pageTitle":'title'},"", 'sssss');
            
    //     }
    //   });
    // });

    var owl = $('.owl-carousel');
    owl.owlCarousel({
        items:1,
        loop:true,
        // margin:10,
        autoplay:true,
        autoplayHoverPause:false
        // autoplayTimeout:200,
    });

    if (parseInt($('.viewer').text()) > 1) {
        var char = $('.viewer').text();
        console.log(char);
        console.log(char.charAt(0));
    }

    if ($(window).width() < 500) {
       $('.ion-android-favorite').css('padding-left','0px');
       $('.fa-users').css('padding-left','9px');
       $('.fa-eye').css('padding-left','9px');
    }
    else {
       $('.ion-android-favorite').css('padding-left','13px');
       $('.fa-users').css('padding-left','13px');
       $('.fa-eye').css('padding-left','13px');
    }

    $('.load_more_official').click(function(argument){
        window.location.href = baseUrl + '/novel_load_more/'+'official';
    })
    $('.load_more_popular').click(function(argument){
        window.location.href = baseUrl + '/novel_load_more/'+'popular';
    })
    $('.load_more_like').click(function(argument){
        window.location.href = baseUrl + '/novel_load_more/'+'like';
    })
    $('.load_more_latest').click(function(argument){
        window.location.href = baseUrl + '/novel_load_more/'+'latest';
    })
    

</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts_frontend._main_frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>