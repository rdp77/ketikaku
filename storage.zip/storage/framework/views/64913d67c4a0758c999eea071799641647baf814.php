   
<link rel="stylesheet" href="<?php echo e(asset('assets/scripts/bootstrap/bootstrap.min.css')); ?>">
<!-- IonIcons -->
<link rel="stylesheet" href="<?php echo e(asset('assets/scripts/ionicons/css/ionicons.min.css')); ?>">
<!-- Toast -->
<link rel="stylesheet" href="<?php echo e(asset('assets/scripts/toast/jquery.toast.min.css')); ?>">
<!-- OwlCarousel -->
<link rel="stylesheet" href="<?php echo e(asset('assets/scripts/owlcarousel/dist/assets/owl.carousel.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/scripts/owlcarousel/dist/assets/owl.theme.default.min.css')); ?>">
<!-- Magnific Popup -->
<link rel="stylesheet" href="<?php echo e(asset('assets/scripts/magnific-popup/dist/magnific-popup.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/scripts/sweetalert/dist/sweetalert.css')); ?>">
<!-- Custom style -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/skins/ketikaku.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/demo.css')); ?>">
<link href="<?php echo e(asset('assets_backend/libs/iziToast-master/dist/css/iziToast.css')); ?>" rel="stylesheet" type="text/css" >
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('dist/css/icons/font-awesome/css/fontawesome-all.css')); ?>">
<link href="<?php echo e(asset('assets_backend/libs/datatables.net-bs4/css/dataTables.bootstrap4.css')); ?>" rel="stylesheet">
  	
<style type="text/css">
	article figure{
		margin-bottom: -10px !important;
	}
	.modal-content {
		border-radius:0px !important;
	}
</style>