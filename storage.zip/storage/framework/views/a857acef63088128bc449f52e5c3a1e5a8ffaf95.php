

<?php $__env->startSection('extra_styles'); ?>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-5 align-self-center">
                        <h4 class="page-title">Profile Page</h4>
                        <div class="d-flex align-items-center">

                        </div>
                    </div>
                    <div class="col-7 align-self-center">
                        <div class="d-flex no-block justify-content-end align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="#">Home</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">Library</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div >
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                    <!-- Column -->
                    <div class="col-lg-4 col-xlg-3 col-md-5">
                        <div class="card">
                            <div class="card-body">
                                <center class="m-t-30"> 
                                <div class="form-group preview_div">
                                    
                                        <div class="col-md-12">

                                        <?php if(Auth::user()->m_image == null): ?>
                                        <div class="preview_td">
                                            <img src="<?php echo e(asset('assets_backend/images/no_image.png')); ?>?<?php echo e(time()); ?>" class="output rounded-circle" width="150" height="145" />
                                        </div>
                                        <?php else: ?>
                                        <div class="preview_td">
                                            <img src="<?php echo e(asset('/storage/app/'.Auth::user()->m_image)); ?>?<?php echo e(time()); ?>" class="output rounded-circle" width="150" height="145" />
                                        </div>
                                        <?php endif; ?>
                                        
                                            <br>
                                            <form class="save_image">
                                                <div class="col-lg-8 col-md-8 col-sm-6">
                                                    <div class="file-upload upl_1" >
                                                        <div class="file-select">
                                                            <div class="file-select-button fileName" >chooseFile</div>
                                                            <div class="file-select-name noFile tag_image_1" >Image</div> 
                                                            <input type="file" class="chooseFile" name="dn_cover">
                                                        </div>
                                                    </div>
                                                    
                                                        
                                                    
                                                </div>
                                            </form>
                                           
                                        </div>
                                    </div>
                                    <h4 class="card-title m-t-10"><?php echo e(Auth::user()->m_name); ?></h4>
                                    <h6 class="card-subtitle"><?php echo e(Auth::user()->m_desc_short); ?></h6>
                                    <div class="row text-center justify-content-md-center">
                                        <div class="col-4"><a href="javascript:void(0)" class="link"><i class="fas fa-user"></i> <font class="font-medium"><?php echo e(Auth::user()->m_follower); ?></font></a></div>
                                        <div class="col-4"><a href="javascript:void(0)" class="link"><i class="fas fa-book"></i> <font class="font-medium"><?php echo e($total_book); ?></font></a></div>
                                    </div>
                                </center>
                            </div>
                            <div>
                                <hr> </div>
                            <div class="card-body"> 
                                <small class="text-muted">Email address </small>
                                <h6><?php echo e(Auth::user()->m_email); ?></h6> 
                                <small class="text-muted p-t-30 db">Social Profile</small>
                                <br>   
                                <button class="btn btn-circle btn-secondary"><i class="fab fa-facebook-f"></i></button>
                                <button class="btn btn-circle btn-secondary"><i class="fab fa-twitter"></i></button>
                                <button class="btn btn-circle btn-secondary"><i class="fab fa-youtube"></i></button>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                    <!-- Column -->
                    <div class="col-lg-8 col-xlg-9 col-md-7">
                        <div class="card">
                            <!-- Tabs -->
                            <ul class="nav nav-pills custom-pills" id="pills-tab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="pills-timeline-tab" data-toggle="pill" href="#current-month" role="tab" aria-controls="pills-timeline" aria-selected="true">Timeline</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#last-month" role="tab" aria-controls="pills-profile" aria-selected="false">Profile</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="pills-setting-tab" data-toggle="pill" href="#previous-month" role="tab" aria-controls="pills-setting" aria-selected="false">Setting</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="pills-setting-tab" data-toggle="pill" href="#social_media" role="tab" aria-controls="pills-setting" aria-selected="false">Social Media</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="pills-setting-tab" data-toggle="pill" href="#change_password" role="tab" aria-controls="pills-setting" aria-selected="false">Change Password</a>
                                </li>
                            </ul>
                            <!-- Tabs -->
                            <div class="tab-content" id="pills-tabContent">
                                <div class="tab-pane fade show active" id="current-month" role="tabpanel" aria-labelledby="pills-timeline-tab">
                                    <div class="card-body">
                                        <div class="profiletimeline m-t-0">
                                           <?php if(count($novel) == 0): ?>
                                                <p>History kosong</p>
                                           <?php endif; ?>
                                           <?php $__currentLoopData = $novel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <hr>
                                            <div class="sl-item">
                                                <div class="sl-left"> <img src="<?php echo e(asset('assets_backend/images/users/2.jpg')); ?>" alt="user" class="rounded-circle" /> </div>
                                                <div class="sl-right">
                                                    <div> <a href="javascript:void(0)" class="link"><?php echo e(Auth::user()->m_username); ?> <small>aka <?php echo e(Auth::user()->m_name); ?></small></a> <span class="sl-date"><?php echo e(date('d F Y h:i:s',strtotime($element->dn_created_at))); ?></span>
                                                        <div class="m-t-20 row">
                                                            <div class="col-md-3 col-xs-12"><img src="<?php echo e(asset('/storage/app/'.$element->dn_cover)); ?>" width="100px" height="400px" alt="user" class="img-fluid rounded" /></div>
                                                            <div class="col-md-9 col-xs-12">
                                                                <?php echo substr(strip_tags($element->dn_description),0,150); ?>

                                                                <?php echo strlen($element->dn_description) > 50 ?  ".....  <button href='' class='btn btn-secondary btn-xs' onclick='readmore(".$element->dn_id.")'> Readmore </button>" : ""; ?>  
                                                                <br><br>
                                                                
                                                                 <a href="<?php echo e(asset('/book/'.$element->dn_id.'/'.str_replace(" ","-",$element->dn_title))); ?>" class="btn-sm btn btn-success"><i class="fas fa-eye"></i> View </a>
                                                                
                                                            </div>
                                                        </div>
                                                        <div class="like-comm m-t-20"> 
                                                            

                                                            

                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <hr>
                                            <?php if(count($novel) > 5): ?>
                                                <a href="javascript:void(0)" class="btn btn-success"> More</a>
                                            <?php endif; ?>
                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="last-month" role="tabpanel" aria-labelledby="pills-profile-tab">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-6 col-xs-6 b-r"> <strong>Name</strong>
                                                <br>
                                                <p class="text-muted"><?php echo e(Auth::user()->m_name); ?></p>
                                            </div>
                                            <div class="col-md-6 col-xs-6 b-r"> <strong>Email</strong>
                                                <br>
                                                <p class="text-muted"><?php echo e(Auth::user()->m_email); ?></p>
                                            </div>
                                        </div>
                                        <hr>
                                        <p class="m-t-30"><?php echo Auth::user()->m_desc_full; ?>

                                    </div>
                                </div>
                                <div class="tab-pane fade" id="social_media" role="tabpanel" aria-labelledby="pills-profile-tab">
                                    <div class="card-body">
                                        <form class="form-horizontal form-material" id="form_save_sosmed">
                                            <div class="form-group">
                                                <label class="col-md-12"> Facebook </label>
                                                <div class="col-md-12">
                                                    <input type="text" value="<?php echo e(Auth::user()->m_facebook); ?>" class="form-control form-control-line" name="m_facebook">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="example-email" class="col-md-12"> Instagram</label>
                                                <div class="col-md-12">
                                                    <input type="email" value="<?php echo e(Auth::user()->m_instagram); ?>" class="form-control form-control-line" name="m_instagram" id="m_email">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="example-email" class="col-md-12"> Twitter</label>
                                                <div class="col-md-12">
                                                    <input type="email" value="<?php echo e(Auth::user()->m_twitter); ?>" class="form-control form-control-line" name="m_twitter" id="m_email">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="example-email" class="col-md-12"> Youtube</label>
                                                <div class="col-md-12">
                                                    <input type="email" value="<?php echo e(Auth::user()->m_youtube); ?>" class="form-control form-control-line" name="m_youtube" id="m_email">
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <div class="col-sm-12">
                                                    <button type="button" onclick="save_sosmed()" class="btn btn-success">Update Profile</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="previous-month" role="tabpanel" aria-labelledby="pills-setting-tab">
                                    <div class="card-body">
                                        <form class="form-horizontal form-material" id="form_save">
                                            <div class="form-group">
                                                <label class="col-md-12">Name <span class="text-danger">*</span></label>
                                                <div class="col-md-12">
                                                    <input type="text" value="<?php echo e(Auth::user()->m_name); ?>" class="form-control form-control-line" name="m_name">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="example-email" class="col-md-12">Email <span class="text-danger">*</span></label>
                                                <div class="col-md-12">
                                                    <input type="email" value="<?php echo e(Auth::user()->m_email); ?>" class="form-control form-control-line" name="m_email" id="m_email">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-12">Desc Short</label>
                                                <div class="col-md-12">
                                                    <textarea  class="form-control form-control-line" rows="5" name="m_desc_short"><?php echo e(Auth::user()->m_desc_short); ?></textarea>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-12">Desc Full</label>
                                                <div class="col-md-12">
                                                    <textarea  class="form-control form-control-line" rows="8" name="m_desc_full"><?php echo e(Auth::user()->m_desc_full); ?></textarea>
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <div class="col-sm-12">
                                                    <button type="button" onclick="save()" class="btn btn-success">Update Profile</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="change_password" role="tabpanel" aria-labelledby="pills-profile-tab">
                                    <div class="card-body">
                                       
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php $__env->stopSection(); ?>

<?php $__env->startSection('extra_scripts'); ?>





<script type="text/javascript">
    

    function readmore(argument) {
        // alert(argument);
    }

        $('.chooseFile').bind('change', function () {
            var filename = $(this).val();
            var fsize = $(this)[0].files[0].size;
            if(fsize>1048576) //do something if file size more than 1 mb (1048576)
            {
              iziToast.warning({
                icon: 'fa fa-times',
                message: 'File Is To Big!',
              });
              return false;
            }
            var parent = $(this).parents(".preview_div");
            if (/^\s*$/.test(filename)) {
                $(parent).find('.file-upload').removeClass('active');
                $(parent).find(".noFile").text("No file chosen..."); 
            }
            else {
                $(parent).find('.file-upload').addClass('active');
                $(parent).find(".noFile").text(filename.replace("C:\\fakepath\\", "")); 
                
                var form  = $('.save_image');
                formdata = new FormData(form[0]);

                $.ajaxSetup({
                  headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "post",
                    url:'<?php echo e(route('master_user_image_update')); ?>',
                    data: formdata ? formdata : form.serialize(),
                    processData: false,
                    contentType: false,
                    success:function(data){
                    if (data.status == 'sukses') {
                        iziToast.success({
                            icon: 'fa fa-save',
                            position:'topRight',
                            title: 'Success!',
                            message: 'Data Berhasil Disimpan!',
                        });

                    // location.reload();
                    }
                  }
                });
            }
            load(parent,this);
        });

        function load(parent,file) {
            var fsize = $(file)[0].files[0].size;
            if(fsize>2048576) //do something if file size more than 1 mb (1048576)
            {
              iziToast.warning({
                icon: 'fa fa-times',
                message: 'File Is To Big!',
              });
              return false;
            }
            var reader = new FileReader();
            reader.onload = function(e){
                $(parent).find('.output').attr('src',e.target.result);
            };
            reader.readAsDataURL(file.files[0]);
        }

        // $(document).ready(function() {

            if ($("#mymce").length > 0) {
                tinymce.init({
                    selector: "textarea#mymce",
                    theme: "modern",
                    height: 300,
                    plugins: [
                        "advlist autolink link image lists charmap print preview hr anchor pagebreak spellchecker",
                        "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
                        "save table contextmenu directionality emoticons template paste textcolor"
                    ],
                    toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | l      ink image | print preview media fullpage | forecolor backcolor emoticons",

                });
            }
        // });

        function save() {
           iziToast.show({
            overlay: true,
            close: false,
            timeout: 20000, 
            color: 'dark',
            icon: 'fas fa-question-circle',
            title: 'Save Data!',
            message: 'Apakah Anda Yakin ?!',
            position: 'center',
            progressBarColor: 'rgb(0, 255, 184)',
            buttons: [
            [
                '<button style="background-color:#17a991;color:white;">Save</button>',
                function (instance, toast) {
                  tinyMCE.triggerSave();
                  var comment = $("#mytextarea").val();

                  $.ajaxSetup({
                      headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    var form = $('#form_save');

                    $.ajax({
                        type: "get",
                        url:'<?php echo e(route('master_user_update')); ?>',
                        data: form.serialize(),
                        processData: false,
                        contentType: false,
                      success:function(data){
                        if (data.status == 'sukses') {
                            iziToast.success({
                                icon: 'fa fa-save',
                                position:'topRight',
                                title: 'Success!',
                                message: 'Data Berhasil Disimpan!',
                            });

                        // location.reload();
                        }
                      },error:function(){
                        iziToast.error({
                            icon: 'fa fa-info',
                            position:'topRight',
                            title: 'Error!',
                            message: data.message,
                        });
                      }
                    });
                    instance.hide({
                        transitionOut: 'fadeOutUp'
                    }, toast);
                }
            ],
            [
                '<button style="background-color:#d83939;color:white;">Cancel</button>',
                function (instance, toast) {
                  instance.hide({
                    transitionOut: 'fadeOutUp'
                  }, toast);
                }
              ]
            ]
        });
        }

    function save_sosmed(argument) {
        $.ajax({
            type: "get",
            url:'<?php echo e(route('master_user_update_sosmed')); ?>',
            data: $('#form_save_sosmed').serialize(),
            processData: false,
            contentType: false,
          success:function(data){
            if (data.status == 'sukses') {
                iziToast.success({
                    icon: 'fa fa-save',
                    position:'topRight',
                    title: 'Success!',
                    message: 'Data Berhasil Disimpan!',
                });
            }
          },error:function(){
            iziToast.error({
                icon: 'fa fa-info',
                position:'topRight',
                title: 'Error!',
                message: 'Try Again Later!',
            });
          }
        });
    }

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts_backend._main_backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>