

<?php $__env->startSection('extra_styles'); ?>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <?php if(session()->has('succes')): ?>
            <div class="bg-light no-card-border">
                <div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">×</span> </button>
                        <h3 class="text-success"><i class="fa fa-info-circle"></i> Pemberitahuan</h3> Selamat Akun anda sudah terverifikasi
                </div>
            </div>
        <?php endif; ?>
        <?php if(Auth::user()->m_isactive == 'N'): ?>
            <div class="bg-light no-card-border">
                <div class="alert alert-warning">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">×</span> </button>
                        <h3 class="text-warning"><i class="fa fa-info-circle"></i> Peringatan</h3> Verifikasi ke email  <?php echo e(Auth::user()->m_email); ?>   diperlukan agar mendapatkan akses untuk menulis. email verifikasi akan membutuhkan beberapa waktu. Mohon cek folder SPAM apabila email tidak di temukan di kotak masuk (UTAMA) <a href="#" onclick="verify()" class="btn btn-primary btn-sm"> <b><strong> Verifikasi </strong></b></a>
                        <br>
                        
                </div>
            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="card  bg-light no-card-border">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="m-r-10">
                                <?php if(Auth::user()->u_image == null): ?>
                                    <img src="<?php echo e(asset('assets_backend/images/no_image.png')); ?>?<?php echo e(time()); ?>" alt="user" width="60" class="rounded-circle" />
                                <?php else: ?>
                                    <img src="<?php echo e(asset('assets_backend/images/user/5.jpg')); ?>?<?php echo e(time()); ?>" alt="user" width="60" class="rounded-circle" />
                                <?php endif; ?>
                            </div>
                            <div>
                                <h3 class="m-b-0">Selamat Datang!</h3>
                                <span><?php echo e(date('F ,d Y')); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
</div>

        <?php $__env->stopSection(); ?>

<?php $__env->startSection('extra_scripts'); ?>
<script type="text/javascript">


    function verify() {
        $('.preloader').show();
        $.ajaxSetup({
          headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.ajax({
                type: "get",
                url:baseUrl+'/verify/'+'<?php echo e(Auth::user()->m_token); ?>'+'/'+'<?php echo e(Auth::user()->m_code); ?>',
                processData: false,
                contentType: false,
              success:function(data){
                if (data.status == 'sukses') {
                            iziToast.success({
                                icon: 'fa fa-save',
                                position:'topRight',
                                title: 'Success!',
                                message: 'Email Telah Terkirim',
                            });
                }
                    $('.preloader').hide();
              },error:function(){
                iziToast.error({
                    icon: 'fa fa-info',
                    position:'topRight',
                    title: 'Error!',
                    message: 'Try Again Later!',
                });
              }
            });
    }


</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts_backend._main_backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>