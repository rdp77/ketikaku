<!DOCTYPE html>
<html>
<head>
    <title></title>
    <?php echo $__env->make('layouts_backend._head_backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('layouts_backend._css_backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
<div class="preloader">
    <div class="lds-ripple">
        <div class="lds-pos"></div>
        <div class="lds-pos"></div>
    </div>
</div>
<div id="main-wrapper">
<div class="auth-wrapper d-flex no-block justify-content-center align-items-center" style="background:url(<?php echo e(asset('assets_backend/images/big/auth-bg.jpg')); ?>) no-repeat center center;">
    <div class="auth-box">
        <div id="loginform">
            <div class="logo">
                <span class="db"><img src="<?php echo e(asset('assets_backend/images/logo-text.png')); ?>" width="120px" alt="logo" /></span>
                <h5 class="font-medium m-b-20">&nbsp;</h5>
            </div>
            <!-- Form -->
            <div class="row">
                <div class="col-12">
                    <form method="get" action="<?php echo e(route('forgot_password_send_email')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="basic-addon1"><i class="ti-user"></i></span>
                            </div>

                            <input id="email" type="text" class="form-control form-control-lg email" name="email" placeholder="email" value="<?php echo e(old('email')); ?>" autofocus aria-label="email" aria-describedby="basic-addon1">
                        </div>

                        <?php if($errors->any()): ?>
                                <?php if( $errors->first() == 'sukses'): ?>
                                    <h3 class="text-center"><span class="badge badge-success">Your Request Has ben Send</span></h3>
                                <?php elseif($errors->first() == 'kosong'): ?>
                                    <h3 class="text-center"><span class="badge badge-warning">Email Doesn't Exist</span></h3>
                                <?php else: ?>
                                    <h3 class="text-center"><span class="badge badge-error">System is Busy. Try Again later</span></h3>
                                <?php endif; ?>
                        <?php endif; ?>
                        
                        <div class="form-group text-center">
                            <div class="col-xs-12 p-b-20">
                                <button class="btn btn-block btn-lg btn-info " type="submit">Send Email</button>
                            </div>
                        </div>
                        <div class="form-group m-b-0 m-t-10">
                            <div class="col-sm-12 text-center">
                                Create Account <a href="<?php echo e(url('register')); ?>" class="text-info m-l-5"><b>Sign Up</b></a> , Already have <a href="<?php echo e(url('login')); ?>" class="text-info m-l-5"><b>Login</b></a>
                            </div>
                        </div>
                        <div class="form-group m-b-0 m-t-10">
                            <div class="col-sm-12 text-center">
                                <a href="<?php echo e(url('/')); ?>" class="text-info m-l-5"><b>Back to Homepage</b></a>
                            </div>
                        </div>
                        
                    </form>
                </div>
            </div>
        </div>
        
    </div>
</div>
</div>
    <?php echo $__env->make('layouts_backend._scripts_backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>

<script type="text/javascript">
    $('.send').click(function(){
        if ($('.email').val() == '') {
            iziToast.Warning({
                icon: 'fa fa-info',
                position:'topRight',
                title: 'Warning!',
                message: 'Email Cannot be empty!',
            });
        // return false;
        }
        $('.send').text('sending..');
        $('.send').attr('disabled','disabled');
    })
</script>